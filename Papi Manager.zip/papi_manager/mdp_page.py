from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QSpacerItem, QSizePolicy, QDialog, QLineEdit, QMessageBox, QScrollArea
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from custom_menu import CustomMenu
from button_image import ImageButton
import os
import sqlite3
from database_manager import create_database, insert_compte, get_comptes, delete_compte_from_database
from functools import partial



class MdpPage(QWidget):
    def __init__(self, custom_menu):
        super().__init__()
        self.custom_menu = custom_menu
        self.initUI()

    def initUI(self):
        self.setFixedSize(1000, 700)
        self.setStyleSheet("background-color: black; color: white;")
        layout = QVBoxLayout(self)

        menu_layout = QHBoxLayout()
        layout.addLayout(menu_layout)

        self.menu_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/menu-white.png"))
        self.menu_button.clicked.connect(self.menu_button_clicked)
        menu_layout.addWidget(self.menu_button, alignment=Qt.AlignTop | Qt.AlignLeft)

        self.welcome_label = QLabel("... Mots De Passes ...")
        font = QFont("Poppins", 17, QFont.Bold)
        self.welcome_label.setFont(font)
        layout.addWidget(self.welcome_label, alignment=Qt.AlignHCenter | Qt.AlignTop)
        self.welcome_label.setStyleSheet("margin-bottom: 20px;")

        self.scroll_area = QScrollArea()
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # Désactiver la barre de défilement horizontale
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)  # Afficher la barre de défilement verticale si nécessaire
        layout.addWidget(self.scroll_area)

        content_widget = QWidget()
        # Ajouter QVBoxLayout ici
        content_layout = QVBoxLayout(content_widget)
        # Ajouter cette ligne pour supprimer la marge par défaut
        content_layout.setContentsMargins(0, 0, 0, 0)
        # Continuer avec le reste du code
        self.scroll_area.setWidget(content_widget)

        self.plus_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/plus.png"))
        self.plus_button.clicked.connect(self.plus_button_clicked)
        layout.addWidget(self.plus_button, alignment=Qt.AlignHCenter)

        self.content_widget = content_widget
        self.content_layout = content_layout

        # Initialiser le dictionnaire des comptes et mots de passe
        self.comptes_mdp = {}

        # Appel à la méthode pour afficher les données depuis la base de données
        self.update_comptes_mdp_layout()

    def menu_button_clicked(self):
        self.custom_menu.toggle_menu()

    def plus_button_clicked(self):
        dialog = InsertCompteDialog(self)
        if dialog.exec_():
            nom_compte = dialog.get_nom_compte()
            mot_de_passe = dialog.get_mot_de_passe()
            mot_de_passe_confirm = dialog.get_mot_de_passe_confirm()

            if mot_de_passe == mot_de_passe_confirm:
                if nom_compte not in self.comptes_mdp:
                    # Ajouter le compte et mot de passe à la base de données
                    insert_compte(nom_compte, mot_de_passe)

                    print("Insertion des données dans la base de données :")
                    print("Nom du compte :", nom_compte)
                    print("Mot de passe :", mot_de_passe)

                    # Mettre à jour l'affichage des comptes et mots de passe
                    self.update_comptes_mdp_layout()
                else:
                    QMessageBox.critical(self, "Erreur", "Le compte existe déjà. Veuillez choisir un autre nom de compte.")
            else:
                QMessageBox.critical(self, "Erreur", "Les mots de passe ne sont pas identiques. Veuillez réessayer.")

    def supprimer_compte_mdp(self, compte):
        reply = QMessageBox.question(self, "Supprimer", f"Voulez-vous vraiment supprimer le compte {compte}?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:

            delete_compte_from_database(compte)

            # Mettre à jour le dictionnaire self.comptes_mdp en récupérant les données de la base de données
            self.comptes_mdp = self.get_data_from_database()

            print("Suppression du compte et mot de passe :", compte)
            print("Comptes et MDP actuels :", self.comptes_mdp)  # Debug

            # Mettre à jour l'affichage des comptes et mots de passe
            self.update_comptes_mdp_layout()

    def update_comptes_mdp_layout(self):
        # Effacer le layout de contenu actuel
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            if item:
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        self.comptes_mdp = self.get_data_from_database()

        # Ajouter les comptes et les mots de passe au layout
        for compte, mdp in self.comptes_mdp.items():
            compte_mdp_layout = CompteMdpWidget(compte, mdp)
            compte_mdp_layout.delete_button.clicked.connect(partial(self.on_delete_button_clicked, compte))

            self.content_layout.addWidget(compte_mdp_layout)

            # Ajouter un espace entre les éléments
            spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
            self.content_layout.addItem(spacer)

        # Réinitialiser l'espace entre les widgets à 0
        self.content_layout.setSpacing(0)

        self.content_widget.setMinimumSize(self.scroll_area.width(), self.content_layout.sizeHint().height())


    def on_delete_button_clicked(self, compte):
        self.supprimer_compte_mdp(compte)
        sender = self.sender()
        if isinstance(sender, QPushButton):
            compte_mdp_widget = sender.parent()
            if isinstance(compte_mdp_widget, CompteMdpWidget):
                self.supprimer_compte_mdp(compte_mdp_widget.compte_label.text())

    def get_data_from_database(self):
        # Récupérer les comptes et mots de passe depuis la base de données
        comptes = get_comptes()

        comptes_mdp = {}
        for compte in comptes:
            username, password = compte[1:]
            comptes_mdp[username] = password

        return comptes_mdp


class CompteMdpWidget(QWidget):
    def __init__(self, compte, mdp, parent=None):
        super().__init__(parent)
        self.initUI(compte, mdp)

    def initUI(self, compte, mdp):
        layout = QHBoxLayout(self)
        self.compte_label = QLabel()
        self.mdp_label = QLabel()
        self.delete_button = QPushButton("❌")

        layout.addWidget(self.compte_label)
        layout.addWidget(self.mdp_label)
        layout.addWidget(self.delete_button)

        self.set_compte_mdp(compte, mdp)  # Afficher les données du compte

        # Connexion du bouton "Supprimer" à la méthode de suppression
        self.delete_button.clicked.connect(self.supprimer_compte_mdp)

    def set_compte_mdp(self, compte, mdp):
        # Définir la police et la taille d'écriture souhaitées ici
        font = QFont("Arial", 18, QFont.Normal)
        self.compte_label.setFont(font)
        self.mdp_label.setFont(font)

        self.compte_label.setText(compte)
        self.mdp_label.setText(mdp)

    def supprimer_compte_mdp(self):
        compte = self.compte_label.text()
        self.parent().supprimer_compte_mdp(compte)
        self.deleteLater()


class InsertCompteDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ajouter un compte et un mot de passe")
        layout = QVBoxLayout(self)

        self.nom_label = QLabel("Nom du compte :")
        layout.addWidget(self.nom_label)

        self.nom_edit = QLineEdit()
        layout.addWidget(self.nom_edit)

        self.mdp_label = QLabel("Mot de passe :")
        layout.addWidget(self.mdp_label)

        self.mdp_edit = QLineEdit()
        layout.addWidget(self.mdp_edit)

        self.mdp_confirm_label = QLabel("Confirmer le mot de passe :")
        layout.addWidget(self.mdp_confirm_label)

        self.mdp_confirm_edit = QLineEdit()
        layout.addWidget(self.mdp_confirm_edit)

        self.button_ok = QPushButton("OK")
        self.button_ok.clicked.connect(self.accept)
        layout.addWidget(self.button_ok)

        self.button_cancel = QPushButton("Annuler")
        self.button_cancel.clicked.connect(self.reject)
        layout.addWidget(self.button_cancel)

    def get_nom_compte(self):
        return self.nom_edit.text()

    def get_mot_de_passe(self):
        return self.mdp_edit.text()

    def get_mot_de_passe_confirm(self):
        return self.mdp_confirm_edit.text()
