from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QDialog, QLineEdit, QPushButton, QScrollArea, QSpacerItem, QSizePolicy, QMessageBox
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
from custom_menu import CustomMenu
from button_image import ImageButton
import os
import sqlite3
from database_manager import insert_personne, get_personnes, delete_personne_from_database
from functools import partial


class NumPage(QWidget):
    def __init__(self, custom_menu):
        super().__init__()
        self.custom_menu = custom_menu
        self.initUI()

    def initUI(self):
        self.setFixedSize(1000, 700)
        self.setStyleSheet("background-color: black; color: white;")
        layout = QVBoxLayout(self)

        # Créer un layout horizontal pour le bouton du menu
        menu_layout = QHBoxLayout()
        layout.addLayout(menu_layout)

        # Ajouter le bouton du menu au layout horizontal
        self.menu_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/menu-white.png"))
        self.menu_button.clicked.connect(self.menu_button_clicked)
        menu_layout.addWidget(self.menu_button, alignment=Qt.AlignTop | Qt.AlignLeft)  # Ajouter le bouton du menu

        # Ajouter le reste des éléments au layout vertical
        self.welcome_label = QLabel("📞 Numéro de téléphone 📞")
        font = QFont("Poppins", 20, QFont.Bold)
        self.welcome_label.setFont(font)
        layout.addWidget(self.welcome_label, alignment= Qt.AlignCenter | Qt.AlignTop)
        self.welcome_label.setStyleSheet("margin-bottom: 20px;")

        # Ajouter le QScrollArea avec le contenu ici
        self.scroll_area = QScrollArea()
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # Désactiver la barre de défilement horizontale
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)  # Afficher la barre de défilement verticale si nécessaire
        layout.addWidget(self.scroll_area)

        # Créer un widget pour contenir le contenu de la scroll area
        content_widget = QWidget()
        # Ajouter QVBoxLayout ici
        content_layout = QVBoxLayout(content_widget)
        # Ajouter cette ligne pour supprimer la marge par défaut
        content_layout.setContentsMargins(0, 0, 0, 0)
        # Continuer avec le reste du code
        self.scroll_area.setWidget(content_widget)

        # Ajouter le bouton "plus"
        self.plus_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/plus.png"))
        self.plus_button.setFont(font)
        self.plus_button.clicked.connect(self.plus_button_clicked)
        layout.addWidget(self.plus_button, alignment=Qt.AlignHCenter)

        # Conserver une référence aux widgets pour pouvoir les mettre à jour ultérieurement
        self.content_widget = content_widget
        self.content_layout = content_layout

        # Initialiser le dictionnaire des personnes et numéros de téléphone
        self.personnes_numeros = {}

        # Appel à la méthode pour afficher les données depuis la base de données
        self.update_personnes_layout()

    def menu_button_clicked(self):
        self.custom_menu.toggle_menu()

    def plus_button_clicked(self):
        dialog = InsertPersonneDialog(self)
        if dialog.exec_():
            nom_personne = dialog.get_nom_personne()
            numero = dialog.get_numero()

            # Ajouter la personne et son numéro à la base de données
            insert_personne(nom_personne, numero)

            # Mettre à jour l'affichage des personnes et numéros de téléphone
            self.update_personnes_layout()

    def update_content(self):
        # Effacer le layout de contenu actuel
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            if item:
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        # Récupérer les personnes depuis la base de données
        personnes = get_personnes()

        # Ajouter les personnes au layout
        for nom_personne, numero in personnes:
            personne_numero_layout = PersonneNumeroWidget(nom_personne, numero)
            personne_numero_layout.delete_button.clicked.connect(partial(self.on_delete_button_clicked, nom_personne))

            # Ajouter personne_numero_layout au QVBoxLayout de content_layout (pas content_widget)
            self.content_layout.addWidget(personne_numero_layout)

            # Ajouter un espace entre les éléments
            spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
            self.content_layout.addItem(spacer)

        # Réinitialiser l'espace entre les widgets à 0
        self.content_layout.setSpacing(0)

        # Définir une taille minimale pour le widget contenu
        self.content_widget.setMinimumSize(self.scroll_area.width(), self.content_layout.sizeHint().height())

    def on_delete_button_clicked(self, nom_personne):
        self.supprimer_personne(nom_personne)

    def supprimer_personne(self, nom_personne):
        reply = QMessageBox.question(self, "Supprimer", f"Voulez-vous vraiment supprimer {nom_personne}?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            # Supprimer la personne et son numéro de la base de données
            delete_personne_from_database(nom_personne)

            # Mettre à jour l'affichage des personnes et numéros de téléphone
            self.update_personnes_layout()

    def update_personnes_layout(self):
        # Effacer le layout de contenu actuel
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            if item:
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        self.personnes_numeros = self.get_data_from_database()

        # Ajouter les personnes et les numéros de téléphone au layout
        for personne, numero in self.personnes_numeros.items():
            personne_numero_layout = PersonneNumeroWidget(personne, numero)
            personne_numero_layout.delete_button.clicked.connect(partial(self.on_delete_button_clicked, personne))

            # Ajouter personne_numero_layout au QVBoxLayout de content_layout (pas content_widget)
            self.content_layout.addWidget(personne_numero_layout)

            # Ajouter un espace entre les éléments
            spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
            self.content_layout.addItem(spacer)

        # Réinitialiser l'espace entre les widgets à 0
        self.content_layout.setSpacing(0)

        # Définir une taille minimale pour le widget contenu
        self.content_widget.setMinimumSize(self.scroll_area.width(), self.content_layout.sizeHint().height())

    def get_data_from_database(self):
        # Récupérer les personnes et numéros depuis la base de données
        personnes = get_personnes()

        personnes_numeros = {}
        for personne in personnes:
            nom, numero = personne[1:]  # Ignorer l'id en position 0
            personnes_numeros[nom] = numero

        return personnes_numeros


class PersonneNumeroWidget(QWidget):
    def __init__(self, personne, numero, parent=None):
        super().__init__(parent)
        self.initUI(personne, numero)

    def initUI(self, personne, numero):
        layout = QHBoxLayout(self)
        self.personne_label = QLabel()
        self.numero_label = QLabel()
        self.delete_button = QPushButton("❌")

        layout.addWidget(self.personne_label)
        layout.addWidget(self.numero_label)
        layout.addWidget(self.delete_button)

        self.set_personne_numero(personne, numero)  # Afficher les données de la personne

        # Connexion du bouton "Supprimer" à la méthode de suppression
        self.delete_button.clicked.connect(self.supprimer_personne)

    def set_personne_numero(self, personne, numero):
        # Définir la police et la taille d'écriture souhaitées ici
        font = QFont("Arial", 18, QFont.Normal)
        self.personne_label.setFont(font)
        self.numero_label.setFont(font)

        self.personne_label.setText(personne)
        self.numero_label.setText(numero)

    def supprimer_personne(self):
        # Récupérer le nom de la personne et le transmettre à la méthode de la page parente pour suppression
        personne = self.personne_label.text()
        self.parent().supprimer_personne(personne)
        self.deleteLater()


class InsertPersonneDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ajouter une personne et un numéro de téléphone")
        layout = QVBoxLayout(self)

        self.nom_label = QLabel("Nom de la personne :")
        layout.addWidget(self.nom_label)

        self.nom_edit = QLineEdit()
        layout.addWidget(self.nom_edit)

        self.numero_label = QLabel("Numéro de téléphone :")
        layout.addWidget(self.numero_label)

        self.numero_edit = QLineEdit()
        layout.addWidget(self.numero_edit)

        self.button_ok = QPushButton("OK")
        self.button_ok.clicked.connect(self.accept)
        layout.addWidget(self.button_ok)

        self.button_cancel = QPushButton("Annuler")
        self.button_cancel.clicked.connect(self.reject)
        layout.addWidget(self.button_cancel)

    def get_nom_personne(self):
        return self.nom_edit.text()

    def get_numero(self):
        return self.numero_edit.text()
