
class System:
    def __init__(self):
        self.mdp = {}


    def print_account(self):
        if self.mdp:
            print("Voici la liste de vos Comptes :")
            for compte in self.mdpmdp:
                print(f"・{compte}")
        else:
            print("Vous n'avez pas de comptes enregistrés.")

    def get_mdp(self):
        self.print_account()
        account_selection = input("Veuillez entrer le compte dont vous voulez le mot de passe : ")
        if account_selection in self.mdp:
            print(f"Le mot de passe du compte {account_selection} est", self.mdp[account_selection])
        else:
            print("Le compte spécifié n'existe pas.")

    def register_mdp(self):
        account_name = input("Veuillez entrer le nom du compte à ajouter : ")
        account_password = input("Veuillez entrer le mot de passe du compte : ")
        account_password_verification = input("Veuillez répéter le mot de passe : ")
        if account_password == account_password_verification:
            self.mdp[account_name] = account_password
            print(f"Le compte {account_name} avec le mot de passe {account_password} à été enregistré avec succés.")
        else:
            print("Les mots de passes ne sont pas les mêmes.")
            self.register_mdp()