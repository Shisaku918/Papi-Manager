from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PySide6.QtGui import QPixmap, QFont
from PySide6.QtCore import Qt
from button_image import ImageButton
from custom_menu import CustomMenu
import os

class WelcomePage(QWidget):
    def __init__(self, custom_menu):
        super().__init__()
        self.custom_menu = custom_menu  # Conserver une référence à l'instance de CustomMenu
        self.initUI()
        
    def initUI(self):
        self.setWindowTitle("Papi Manager")
        self.setGeometry(450, 150, 1000, 700)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout(self)

        self.user_label = QLabel()
        # U+200E est un caractère vide
        self.welcome_label = QLabel("‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ 🎐 Bonjour, Papi 🎐\n\n‎ ‎ ‎ Veuillez appuyez sur le bouton en haut à gauche")
        font = QFont("Poppins", 20, QFont.Bold)
        self.welcome_label.setFont(font)
        self.welcome_label.setStyleSheet("color: white; margin-bottom: 150px;")

        # indiquer le chemin des images
        self.user_path = os.path.join(os.path.dirname(__file__), "img/user.png")

        # Créer le bouton image pour le menu
        self.menu_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/menu-white.png"))
        self.menu_button.clicked.connect(self.menu_button_clicked)

        layout.addWidget(self.menu_button, alignment=Qt.AlignTop | Qt.AlignLeft)  # Ajouter le bouton du menu
        layout.addWidget(self.user_label, alignment=Qt.AlignCenter)
        layout.addWidget(self.welcome_label, alignment=Qt.AlignCenter)


        self.user()
        self.user_label.setStyleSheet("margin-right: 30px;")

    def user(self):
        pixmap = QPixmap(self.user_path)
        pixmap = pixmap.scaled(300, 300, Qt.KeepAspectRatio)
        self.user_label.setPixmap(pixmap)

    def menu_button_clicked(self):
        self.custom_menu.toggle_menu()
