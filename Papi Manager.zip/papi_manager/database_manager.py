# database_manager.py

import sqlite3

def create_database():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Créer la table pour les personnes
    cursor.execute('''CREATE TABLE IF NOT EXISTS personnes (
                        id INTEGER PRIMARY KEY,
                        nom TEXT NOT NULL,
                        numero TEXT NOT NULL
                    )''')

    # Créer la table pour les lieux
    cursor.execute('''CREATE TABLE IF NOT EXISTS lieux (
                        id INTEGER PRIMARY KEY,
                        nom TEXT NOT NULL,
                        adresse TEXT NOT NULL
                    )''')

    # Créer la table pour les comptes
    cursor.execute('''CREATE TABLE IF NOT EXISTS comptes (
                        id INTEGER PRIMARY KEY,
                        username TEXT NOT NULL,
                        password TEXT NOT NULL
                    )''')

    conn.commit()
    conn.close()


def insert_personne(nom, numero):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("INSERT INTO personnes (nom, numero) VALUES (?, ?)", (nom, numero))

    conn.commit()
    conn.close()

def insert_lieu(nom, adresse):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("INSERT INTO lieux (nom, adresse) VALUES (?, ?)", (nom, adresse))

    conn.commit()
    conn.close()

def insert_compte(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("INSERT INTO comptes (username, password) VALUES (?, ?)", (username, password))

    conn.commit()
    conn.close()

def get_personnes():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM personnes")
    personnes = cursor.fetchall()

    conn.close()
    return personnes

def get_lieux():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM lieux")
    lieux = cursor.fetchall()

    conn.close()
    return lieux

def get_comptes():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM comptes")
    comptes = cursor.fetchall()

    conn.close()
    return comptes


def delete_compte_from_database(username):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Supprimer le compte avec le nom d'utilisateur spécifié de la table 'comptes'
    cursor.execute("DELETE FROM comptes WHERE username=?", (username,))
    conn.commit()

    conn.close()


def delete_lieu_from_database(nom_lieu):
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    try:
        cursor.execute("DELETE FROM lieux WHERE nom=?", (nom_lieu,))
        conn.commit()
    except Exception as e:
        print("Erreur lors de la suppression du lieu :", str(e))
    finally:
        cursor.close()
        conn.close()


def delete_personne_from_database(nom_personne):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Supprimer la personne avec le nom spécifié de la table 'personnes'
    cursor.execute("DELETE FROM personnes WHERE nom=?", (nom_personne,))
    conn.commit()

    conn.close()