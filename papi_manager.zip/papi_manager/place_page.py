from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QSpacerItem, QSizePolicy, QDialog, QLineEdit, QMessageBox, QScrollArea
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from custom_menu import CustomMenu
from button_image import ImageButton
import os
import sqlite3
from database_manager import insert_lieu, get_lieux, delete_lieu_from_database
from functools import partial

class PlacePage(QWidget):
    def __init__(self, custom_menu):
        super().__init__()
        self.custom_menu = custom_menu
        self.initUI()

    def initUI(self):
        self.setFixedSize(1000, 700)
        self.setStyleSheet("background-color: black; color: white;")
        layout = QVBoxLayout(self)

        # Créer un layout horizontal pour le bouton du menu
        menu_layout = QHBoxLayout()
        layout.addLayout(menu_layout)

        # Ajouter le bouton du menu au layout horizontal
        self.menu_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/menu-white.png"))
        self.menu_button.clicked.connect(self.menu_button_clicked)
        menu_layout.addWidget(self.menu_button, alignment=Qt.AlignTop | Qt.AlignLeft)  # Ajouter le bouton du menu

        # Ajouter le reste des éléments au layout vertical
        self.welcome_label = QLabel("🔎 Adresse 🔎")
        font = QFont("Poppins", 20, QFont.Bold)
        self.welcome_label.setFont(font)
        layout.addWidget(self.welcome_label, alignment= Qt.AlignCenter | Qt.AlignTop)
        self.welcome_label.setStyleSheet("margin-bottom: 20px;")

        # Ajouter le QScrollArea avec le contenu ici
        self.scroll_area = QScrollArea()
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # Désactiver la barre de défilement horizontale
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)  # Afficher la barre de défilement verticale si nécessaire
        layout.addWidget(self.scroll_area)

        # Créer un widget pour contenir le contenu de la scroll area
        content_widget = QWidget()
        # Ajouter QVBoxLayout ici
        content_layout = QVBoxLayout(content_widget)
        # Ajouter cette ligne pour supprimer la marge par défaut
        content_layout.setContentsMargins(0, 0, 0, 0)
        # Continuer avec le reste du code
        self.scroll_area.setWidget(content_widget)

        # Ajouter le bouton "plus"
        self.plus_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/plus.png"))
        self.plus_button.setFont(font)
        self.plus_button.clicked.connect(self.plus_button_clicked)
        layout.addWidget(self.plus_button, alignment=Qt.AlignHCenter)

        self.content_widget = content_widget
        self.content_layout = content_layout

        # Initialiser le dictionnaire des lieux et adresses
        self.lieux_adresses = {}

        # Appel à la méthode pour afficher les données depuis la base de données
        self.update_lieux_adresses_layout()

    def menu_button_clicked(self):
        self.custom_menu.toggle_menu()

    def plus_button_clicked(self):
        dialog = InsertLieuDialog(self)
        if dialog.exec_():
            nom_lieu = dialog.get_nom_lieu()
            adresse = dialog.get_adresse()

            # Ajouter le lieu et l'adresse à la base de données
            insert_lieu(nom_lieu, adresse)

            # Mettre à jour l'affichage des lieux
            self.update_lieux_adresses_layout()

    def update_content(self):
        # Effacer le layout de contenu actuel
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            if item:
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        # Récupérer les lieux depuis la base de données
        lieux = get_lieux()

        # Ajouter les lieux au layout
        for nom_lieu, adresse in lieux:
            lieu_adresse_layout = LieuAdresseWidget(nom_lieu, adresse)
            lieu_adresse_layout.delete_button.clicked.connect(partial(self.on_delete_button_clicked, nom_lieu))

            self.content_layout.addWidget(lieu_adresse_layout)

            # Ajouter un espace entre les éléments
            spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
            self.content_layout.addItem(spacer)

        # Réinitialiser l'espace entre les widgets à 0
        self.content_layout.setSpacing(0)

        # Définir une taille minimale pour le widget contenu
        self.content_widget.setMinimumSize(self.scroll_area.width(), self.content_layout.sizeHint().height())

    def on_delete_button_clicked(self, nom_lieu):
        self.supprimer_lieu(nom_lieu)

    def supprimer_lieu(self, nom_lieu):
        reply = QMessageBox.question(self, "Supprimer", f"Voulez-vous vraiment supprimer le lieu {nom_lieu}?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            # Supprimer le lieu et l'adresse de la base de données
            delete_lieu_from_database(nom_lieu)

            # Mettre à jour l'affichage des lieux
            self.update_lieux_adresses_layout()

    def update_lieux_adresses_layout(self):
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            if item:
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        self.lieux_adresses = self.get_data_from_database()

        # Ajouter les lieux et les adresses au layout
        for lieu, adresse in self.lieux_adresses.items():
            lieu_adresse_layout = LieuAdresseWidget(lieu, adresse)
            lieu_adresse_layout.delete_button.clicked.connect(partial(self.on_delete_button_clicked, lieu))

            # Ajouter lieu_adresse_layout au QVBoxLayout de content_layout (pas content_widget)
            self.content_layout.addWidget(lieu_adresse_layout)

            # Ajouter un espace entre les éléments
            spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
            self.content_layout.addItem(spacer)

        # Réinitialiser l'espace entre les widgets à 0
        self.content_layout.setSpacing(0)

        self.content_widget.setMinimumSize(self.scroll_area.width(), self.content_layout.sizeHint().height())

    def get_data_from_database(self):
        # Récupérer les lieux et adresses depuis la base de données
        lieux = get_lieux()

        lieux_adresses = {}
        for lieu in lieux:
            nom, adresse = lieu[1:]  # Ignorer l'id en position 0
            lieux_adresses[nom] = adresse

        return lieux_adresses


class LieuAdresseWidget(QWidget):
    def __init__(self, lieu, adresse, parent=None):
        super().__init__(parent)
        self.initUI(lieu, adresse)

    def initUI(self, lieu, adresse):
        layout = QHBoxLayout(self)
        self.lieu_label = QLabel()
        self.adresse_label = QLabel()
        self.delete_button = QPushButton("❌")

        layout.addWidget(self.lieu_label)
        layout.addWidget(self.adresse_label)
        layout.addWidget(self.delete_button)

        self.set_lieu_adresse(lieu, adresse)  # Afficher les données du lieu

        # Connexion du bouton "Supprimer" à la méthode de suppression
        self.delete_button.clicked.connect(self.supprimer_lieu)

    def set_lieu_adresse(self, lieu, adresse):
        # Définir la police et la taille d'écriture souhaitées ici
        font = QFont("Arial", 18, QFont.Normal)
        self.lieu_label.setFont(font)
        self.adresse_label.setFont(font)

        self.lieu_label.setText(lieu)
        self.adresse_label.setText(adresse)

    def supprimer_lieu(self):
        # Récupérer le nom du lieu et le transmettre à la méthode de la page parente pour suppression
        lieu = self.lieu_label.text()
        self.parent().supprimer_lieu(lieu)
        self.deleteLater()


class InsertLieuDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ajouter un lieu et une adresse")
        layout = QVBoxLayout(self)

        self.nom_label = QLabel("Nom du lieu :")
        layout.addWidget(self.nom_label)

        self.nom_edit = QLineEdit()
        layout.addWidget(self.nom_edit)

        self.adresse_label = QLabel("Adresse :")
        layout.addWidget(self.adresse_label)

        self.adresse_edit = QLineEdit()
        layout.addWidget(self.adresse_edit)

        self.button_ok = QPushButton("OK")
        self.button_ok.clicked.connect(self.accept)
        layout.addWidget(self.button_ok)

        self.button_cancel = QPushButton("Annuler")
        self.button_cancel.clicked.connect(self.reject)
        layout.addWidget(self.button_cancel)

    def get_nom_lieu(self):
        return self.nom_edit.text()

    def get_adresse(self):
        return self.adresse_edit.text()
