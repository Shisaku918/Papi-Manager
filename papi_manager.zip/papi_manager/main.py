from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFrame, QDialog, QLabel, QLineEdit, QPushButton
from PySide6.QtGui import QPixmap, QFont
from PySide6.QtCore import Qt, QSize
from custom_menu import CustomMenu
from button_image import ImageButton
import os
import sys

# Importez les classes des pages ici
from welcome_page import WelcomePage
from mdp_page import MdpPage
from num_page import NumPage
from place_page import PlacePage

class PasswordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mot de passe requis")
        layout = QVBoxLayout(self)

        self.message_label = QLabel("Veuillez entrer le mot de passe pour accéder à l'application:")
        layout.addWidget(self.message_label)

        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_edit)

        self.button_ok = QPushButton("OK")
        self.button_ok.clicked.connect(self.check_password)
        layout.addWidget(self.button_ok)

    def input_password(self):
        password_input = self.password_edit.text()
        if password_input == "mot_de_passe":
            self.accept()
        else:
            self.password_edit.clear()
            self.password_edit.setPlaceholderText("Mot de passe incorrect")

    def check_password(self):
        password = self.password_edit.text()
        if password == "mot_de_passe":
            self.accept()
        else:
            self.password_edit.clear()
            self.password_edit.setPlaceholderText("Mot de passe incorrect")

class Window(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.current_page = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Shisaku Manager")
        self.setGeometry(450, 150, 1000, 700)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout(self)

        self.page_container = QFrame()
        self.page_container.setLayout(QVBoxLayout())

        layout.addWidget(self.page_container)

        # Créer une instance de CustomMenu
        self.custom_menu = CustomMenu()

        # Passer la référence du CustomMenu à WelcomePage
        self.welcome_page = WelcomePage(self.custom_menu)

        # Afficher la page d'accueil par défaut
        self.show_page(WelcomePage(self.custom_menu))

        layout.addWidget(self.custom_menu)
        self.custom_menu.mdp_button_clicked.connect(self.show_mdp_page)
        self.custom_menu.num_button_clicked.connect(self.show_num_page)
        self.custom_menu.place_button_clicked.connect(self.show_place_page)

        # Afficher le QDialog pour demander le mot de passe
        password_dialog = PasswordDialog(self)
        if password_dialog.exec_() == QDialog.Accepted:
            # Mot de passe correct, continuer avec l'application
            self.show()

    def show_page(self, page_widget):
        self.hide_current_page()
        self.current_page = page_widget
        self.page_container.layout().addWidget(self.current_page)

    def show_mdp_page(self):
        self.show_page(MdpPage(self.custom_menu))

    def show_num_page(self):
        self.show_page(NumPage(self.custom_menu))

    def show_place_page(self):
        self.show_page(PlacePage(self.custom_menu))

    def hide_current_page(self):
        if self.current_page:
            self.page_container.layout().removeWidget(self.current_page)
            self.current_page.deleteLater()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Window()
    sys.exit(app.exec())
