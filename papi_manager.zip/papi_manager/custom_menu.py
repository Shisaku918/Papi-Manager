from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QFrame, QSpacerItem, QSizePolicy
from PySide6.QtGui import QPixmap, QFont
from PySide6.QtCore import Qt, QSize, QPropertyAnimation, Signal
from button_image import ImageButton
import os
import sys

class CustomMenu(QFrame):
    mdp_button_clicked = Signal()
    num_button_clicked = Signal()
    place_button_clicked = Signal()

    def __init__(self):
        super().__init__()
        self.setStyleSheet("background-color: white; color: black; border-radius: 5px;")
        self.setMaximumHeight(0)
        self.animation = QPropertyAnimation(self, b"maximumHeight")
        self.animation.setDuration(400)
        self.is_opened = False

        self.mdp_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/mdp.png"))
        self.num_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/phone.png"))
        self.place_button = ImageButton(os.path.join(os.path.dirname(__file__), "img/place.png"))

        self.mdp_button.setStyleSheet("margin-left: 315px;")

        self.layout = QHBoxLayout(self)
        self.layout.addWidget(self.mdp_button)
        self.layout.addSpacerItem(QSpacerItem(70, 70, QSizePolicy.Fixed, QSizePolicy.Minimum))  # Espacement entre Bouton 1 et Bouton 2
        self.layout.addWidget(self.num_button)
        self.layout.addSpacerItem(QSpacerItem(70, 70, QSizePolicy.Fixed, QSizePolicy.Minimum))  # Espacement entre Bouton 2 et Bouton 3
        self.layout.addWidget(self.place_button)
        self.layout.addSpacerItem(QSpacerItem(70, 70, QSizePolicy.Expanding, QSizePolicy.Minimum))  # Espacement après Bouton 3

        self.layout.addStretch()

        # Connecter les signaux aux méthodes
        self.mdp_button.clicked.connect(self.on_mdp_button_clicked)
        self.num_button.clicked.connect(self.on_num_button_clicked)
        self.place_button.clicked.connect(self.on_place_button_clicked)

    def toggle_menu(self):
        if not self.is_opened:
            self.animation.setStartValue(0)
            self.animation.setEndValue(self.layout.sizeHint().height())
            self.animation.start()
        else:
            self.animation.setStartValue(self.layout.sizeHint().height())
            self.animation.setEndValue(0)
            self.animation.start()
        self.is_opened = not self.is_opened

    def on_mdp_button_clicked(self):
        self.mdp_button_clicked.emit()

    def on_num_button_clicked(self):
        self.num_button_clicked.emit()

    def on_place_button_clicked(self):
        self.place_button_clicked.emit()
